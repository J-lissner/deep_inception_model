import sys
sys.path.append( 'scripts' )
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = "2"
import tensorflow as tf
import tensorflow_addons as tfa
import numpy as np

##custom written packages
import data_processing as get
import tf_functions as tfun
import learner_functions as learn
from conv_models import *
from hybrid_models import * 
from timers import tic, toc
from tf_save_load import Saver
from precompute_data import assemble_data

#################################################################################
## This script trains the hybrid neural network by being given image data
## and feature data. All parameters that should be adjusted are denoted with
## 'adjustable', besides the data which depends on the user.
## If the 'phase_contrast' variable is adjusted to have a higher length than
## 1, then the variable phase contrast is automatically treated and the extra
## neuron inserted. Regarding the ANN evaluation: everything is given in the 
## class in 'tf_functions/hybrid_models.py'
## The part is piecewise documented and can be adjusted to the users preferences,
## at their own discretization obviously.
## It is known that a few lines go beyond the 'recommended number of columns',
## which does not matter to the authors since we have a widescreen ;)
#################################################################################


### Adjustable ANN parameters
n_NN                = 5 #how many NN do we want
validation_split    = 0.20 #20 % for validation
epochs              = 10000
roll_interval       = 10 #after how many images half of the images should be rolled/translated
roll_part           = 0.5 #percentage of rolled images
stopping_delay      = 500
learning_rate       = learn.RemoteLR() #0.005
n_data              = 3000 #note that this is the sum of "n" training AND validation data
batchsize           = 50
debug_counter       = 15
input_scaletype     = 'single_std1'
extra_scaletype     = '0,1' #for variable phase contrast
extra_idx           = 1 #for variable phase contrast
get_extra           = lambda x: x[:, extra_idx][:,None]
output_scaletype    = None#'-1,1'
pretrain_model      = True
pretrain_vol        = False
save_path           = 'trained_models/hybrid_lr_schedule'
model_name          = 'DecoupledFeatures' 
phase_contrast      = [5]
## other things required for the saver
model_code = 'hybrid_models'
auxiliary_code = [  'data_processing', 'tf_functions', 'train_hybrid.py' ]
## load data
features, target, images = assemble_data( n_data, request_images=True, phase_contrast=phase_contrast) 
images                   = images.reshape( -1, 400, 400, 1).astype( np.float32) 
n_batches           = images.shape[0]//batchsize #or folds for cross validation
## variable computation
plateau_threshold = 0.95 if learn.is_slashable( learning_rate) else 1
n_vol          = min(2, len(phase_contrast) ) #2 features for variable phase contrast
variable_model = True if len(phase_contrast) > 1 else False
n_batches      = n_batches * len( phase_contrast) 
valid_batches  = round( validation_split*n_batches)

### LOOP FOR DIFFERENT NN
for j in range( n_NN): 
    #### DATA PRE PROCESSING
    x_train, y_train, x_valid, y_valid, img_train, img_valid = get.split_data( features, target, validation_split, slave_inputs=images)
    x_train, x_valid, input_scaling                          = get.scale_data( x_train, x_valid, scaletype=input_scaletype)
    y_train, y_valid, output_scaling                         = get.scale_data( y_train, y_valid, scaletype=output_scaletype)
    if variable_model:
        x_extra, x_vextra, extra_scaling = get.scale_data( get_extra(x_train), get_extra( x_valid), scaletype=extra_scaletype)
        x_train[:,extra_idx]             = x_extra.squeeze()
        x_valid[:,extra_idx]             = x_vextra.squeeze()
    x_train, x_valid, y_train, y_valid, img_train= tfun.to_float32( x_train, x_valid, y_train, y_valid, img_train )
    img_train = tf.Variable( img_train)

    
    ## Parameters required for the saver object
    savepath     = f'{save_path}_nr_{j}'
    model_args   = [y_train.shape[1]]
    model_kwargs = dict( n_vol=n_vol)
    ANN                = eval( model_name)( *model_args, **model_kwargs)
    ### Adjustable parameters for ANN optimization (has to be inside the loop)
    loss_metric   = tf.keras.losses.MeanSquaredError() #validate with
    cost_function = tf.function( tfun.relative_mse ) if variable_model else tf.keras.losses.MeanSquaredError()#optimize with
    if learn.is_slashable( learning_rate):
        optimizer = tfa.optimizers.AdamW( learning_rate=learning_rate, weight_decay=1e-4, beta_1=0.8, beta_2=0.85)
        learning_rate.reference_optimizer( optimizer)
        learning_rate.reference_model( ANN)
    else:
        optimizer = tfa.optimizers.AdamW( weight_decay=1e-5, learning_rate=learning_rate)
    checkpoints        = tf.train.Checkpoint( model=ANN, optimizer=optimizer)
    checkpoint_manager = tf.train.CheckpointManager( checkpoints, savepath, max_to_keep=3 )

    ###### Model pretraining of selected layers #####
    print( '######################### STARTING PRETRAINING #########################' )
    ## allocate full model
    tic( 'one entire training', silent=True )
    ANN( x_valid[:2], img_valid[:2] ) #model allocation required for 'pretrain_section'
    if pretrain_model:
      batching = dict( valid_batches=valid_batches, n_batches=n_batches)
      ANN.freeze_all()
      ### pretraining of all models
      predictors = [ANN.predict_vol, ANN.call, ANN.predict_features, ANN.predict_inception] 
      freezers   = [ANN.freeze_vol, ANN.all_but_vol, ANN.freeze_feature_predictor, ANN.freeze_inception]
      kwargs     = [dict(n_epochs=150), dict(n_epochs=150, **batching), dict(), dict(roll_x0=True, **batching) ]
      for kwarg in kwargs[2:]:
        kwarg['learning_rate'] = 'variable' if learn.is_slashable( learning_rate) else 'constant'
      if variable_model:
          training_data = [ [x_train], [x_train, img_train], [x_train], [img_train, get_extra( x_train)] ]
          valid_data    = [ [x_valid], [x_valid, img_valid], [x_valid], [img_valid, get_extra( x_valid)] ] 
      else:
          training_data = [ [x_train], [x_train, img_train], [x_train], [img_train] ]
          valid_data    = [ [x_valid], [x_valid, img_valid], [x_valid], [img_valid] ]
      y_residual     = y_train.copy()
      valid_residual = y_valid.copy()
      ### pretrain each section
      for i in range( len( predictors)):
          freezers[i](False)
          if not predictors[i].__name__ == 'call': #should be around the next two lines
              valid_loss = ANN.pretrain_section( [*training_data[i], y_residual],
                      [*valid_data[i], valid_residual], predictor=predictors[i], **kwargs[i]) 
              # predict x_train in batches and compute the remaining y_train
              y_residual -= ANN.batched_partial_prediction( n_batches, predictors[i], *training_data[i] )
              valid_residual -= ANN.batched_partial_prediction( valid_batches, predictors[i], *valid_data[i] )
              print( f'### pretrained "{predictors[i].__name__}", current val loss: {loss_metric( y_valid, y_valid-valid_residual)} ###' )
          else: 
              valid_loss = ANN.pretrain_section( [*training_data[i], y_train],
                      [*valid_data[i], y_valid], predictor=predictors[i], **kwargs[i]) 
              print( f'### pretrained "call", current val loss: {loss_metric( y_valid, ANN.batched_prediction( valid_batches, *valid_data[i]))} ###' )
          freezers[i]()
      valid_loss = [loss_metric( y_valid, ANN.batched_prediction(valid_batches, x_valid, img_valid)) ]
      print( '### Finished full pretraining, current validation loss: {} ###'.format( valid_loss[0] ) ) 
      print( '######################### FULL PRETRAINING FINISHED ######################' )
      ANN.freeze_all( False)
      ANN.freeze_vol()
      del valid_residual, y_residual 
    elif pretrain_vol:
        ANN.freeze_all()
        ANN.freeze_vol( False)
        ANN.pretrain_section( [x_train, y_train], [x_valid, y_valid ],
                              ANN.predict_vol, n_epochs=150 )
        ANN.freeze_all( False)
        ANN.freeze_vol()

    ## variable allocation before training loop
    decline    = 0 #tracked variable for early stop
    best_epoch = 0
    best_loss  = 1e5
    valid_loss = []
    train_loss = [] 
    tic('training model')
    tic('trained for {} epochs'.format( debug_counter), True)
    ### BODY OF TRAINING AND VARIABLE TRACKING
    print( '########################## starting training ##########################')
    for i in range( epochs):
        if (i+1) % roll_interval == 0:
            tfun.roll_images( img_train, roll_part)  #translate the images
        batch_loss   = []
        for x_batch, y_batch, image_batch in tfun.batch_data( n_batches, [ x_train, y_train, img_train]):
            with tf.GradientTape() as tape:
                y_pred   = ANN( x_batch, image_batch, training=True)
                gradient = cost_function( y_batch, y_pred ) 
            gradient = tape.gradient( gradient, ANN.trainable_variables)
            optimizer.apply_gradients( zip(gradient, ANN.trainable_variables) )
            batch_loss.append( loss_metric( y_batch, y_pred) ) 

        # epoch post processing
        y_pred       = ANN.batched_prediction( valid_batches, x_valid, img_valid)
        current_loss = np.mean( cost_function( y_pred, y_valid) )
        valid_loss.append( np.mean( loss_metric( y_pred, y_valid) ))#.numpy() ) )
        train_loss.append( np.mean( batch_loss )  )
        if current_loss < best_loss: 
            best_loss  = current_loss
            best_epoch = i
            decline    = 0
            checkpoint_manager.save() 
        decline += 1
        i       += 1
        if i % debug_counter == 0:
            toc( 'training model', precision=1 )
            toc( f'trained for {debug_counter} epochs', auxiliary=f', {i} total epochs', precision=1) 
            print( f'current validation loss:\t{valid_loss[-1]:.2e} vs best:\t{valid_loss[best_epoch]:.3e}' )
            print( f'vs current train loss:  \t{train_loss[-1]:.2e} vs best:\t{train_loss[best_epoch]:.3e}' )
            tic('trained for {} epochs'.format( debug_counter), True)
        if decline == stopping_delay:
            if learn.is_slashable( learning_rate) and not learning_rate.allow_stopping:
                learning_rate.slash()
                decline = 0
            else:
                break

    ### POST PROCESSING AND SAVING
    ## recover the checkpoint (is automatically the best ANN, even if it improves till the last epoch))
    checkpoints.restore(checkpoint_manager.latest_checkpoint)
    toc('training model')
    toc( 'one entire training' )
    print( 'saving model to"{}"'.format( savepath ) )
    print( f"""######################### training finished #########################,
           trained for {i} epochs, best ANN at {best_epoch} epochs,
           best valid loss:            {np.mean(valid_loss[best_epoch])},
           corresponding train loss:   {np.mean(train_loss[best_epoch])},  
#####################################################################
           """ )
    ## Save trained model
    save = Saver( savepath, model_code, model_name, ANN )
    save.inputs( *model_args, **model_kwargs)
    ## save remaining requirements
    save.locals( optimizer=optimizer, cost_function=cost_function )
    if n_vol > 1:
        save.scaling( input_scaling, output_scaling, extra_scaling=extra_scaling, extra_idx=extra_idx)
    else:
        save.scaling( input_scaling, output_scaling )
    save.tracked_variables( train_loss=train_loss, valid_loss=valid_loss, 
                            best_epoch=best_epoch, epochs=i, stopping_delay=stopping_delay)
    save.code( *auxiliary_code) 
    del ANN, checkpoints, checkpoint_manager, train_loss, valid_loss, cost_function, optimizer

